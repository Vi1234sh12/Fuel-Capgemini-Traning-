package com.example.OnetoManydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnetoManydemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
