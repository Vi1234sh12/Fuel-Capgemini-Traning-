package com.example.SpringSecurityOnlineShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityOnlineShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
