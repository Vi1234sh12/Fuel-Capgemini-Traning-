package com.example.SpringSecurityL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityLApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityLApplication.class, args);
	}

}
