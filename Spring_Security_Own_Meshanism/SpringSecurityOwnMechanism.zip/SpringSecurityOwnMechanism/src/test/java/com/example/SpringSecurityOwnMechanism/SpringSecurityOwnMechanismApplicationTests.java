package com.example.SpringSecurityOwnMechanism;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityOwnMechanismApplicationTests {

	@Test
	void contextLoads() {
	}

}
