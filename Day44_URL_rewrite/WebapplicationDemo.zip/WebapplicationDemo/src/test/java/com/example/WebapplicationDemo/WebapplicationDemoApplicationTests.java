package com.example.WebapplicationDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebapplicationDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
