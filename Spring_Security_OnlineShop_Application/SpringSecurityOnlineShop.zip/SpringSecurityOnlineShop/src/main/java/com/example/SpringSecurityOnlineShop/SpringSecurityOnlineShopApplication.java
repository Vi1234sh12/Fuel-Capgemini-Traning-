package com.example.SpringSecurityOnlineShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityOnlineShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityOnlineShopApplication.class, args);
	}

}
