package com.example.OnetoOneChoice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnetoOneChoiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
