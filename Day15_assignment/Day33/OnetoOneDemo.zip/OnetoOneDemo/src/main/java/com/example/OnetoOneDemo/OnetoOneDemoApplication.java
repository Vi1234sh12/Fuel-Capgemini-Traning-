package com.example.OnetoOneDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnetoOneDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnetoOneDemoApplication.class, args);
	}

}
