package com.example.SpringBootWebdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebdemoApplication.class, args);
	}

}
