package com.example.WebapplicationDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebapplicationDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebapplicationDemoApplication.class, args);
	}

}
