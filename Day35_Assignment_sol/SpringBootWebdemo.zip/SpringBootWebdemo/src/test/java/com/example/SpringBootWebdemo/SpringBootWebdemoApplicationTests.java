package com.example.SpringBootWebdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
