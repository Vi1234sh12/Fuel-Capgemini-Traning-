package com.example.SpringSecurityUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
